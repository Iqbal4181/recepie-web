<?php

$con = mysqli_connect('localhost', 'root', '','practise');

$txtName = $_POST['name'];
$txtEmail = $_POST['email'];
$txtIncrediants = $_POST['incrediants'];
$txtRecepie = $_POST['recepie'];
$txtPeople = $_POST['people'];
$txtMessage = $_POST['message'];

	$sql = "INSERT INTO `recepie` (`id`, `name`, `email` , `incrediants` , `recepie`, `people` , `message`) VALUES ('0', '$txtName', '$txtEmail', '$txtIncrediants', '$txtRecepie', '$txtPeople' , '$txtMessage')";
	$result = mysqli_query($con, $sql);
	if($result)
{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Recepie and opinion Submitted")';  
	echo '</script>';  

 }
 else{
	echo '<script type ="text/JavaScript">';  
	echo 'alert("Recepie and opinion Submit failed")';  
	echo '</script>';  
  
 }






// if($result)
// {
// 	echo "Contact Records Inserted";
// }

?>